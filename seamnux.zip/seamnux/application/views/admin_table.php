<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Document</title>
  <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.1.1/css/bootstrap.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/1.10.19/css/dataTables.bootstrap4.min.css">
  <script src="https://code.jquery.com/jquery-3.3.1.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
  <script src="https://cdn.datatables.net/1.10.19/js/dataTables.bootstrap4.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/twitter-bootstrap/4.5.2/js/bootstrap.min.js"></script>
  <style>
    td{
  word-break:break;
  
}
img{
 
  max-width: 100px;
  width: 100%;
}
  </style>
</head>
<body>
    <!-- for the display the header for the admin -->
  <nav class="navbar navbar-expand-lg navbar-light bg-light">
    <div class="container">
      <a class="navbar-brand" href="#"> <img src="<?=base_url('assets/image/logo_new2.png');?>"> </a>
      <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav" aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="collapse navbar-collapse justify-content-end" id="navbarNav">
        <ul class="navbar-nav">
          <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false"> Admin Dashboard</a>
            <div class="dropdown-menu dropdown-menu-right" aria-labelledby="userDropdown">
              <!-- <a class="dropdown-item" href="#">Profile</a>-->
              <a class="dropdown-item" href="#">Admin</a> 
              <div class="dropdown-divider"></div>
              <a class="dropdown-item" href="<?php echo base_url('admin-logout'); ?>">Logout</a>
            </div>
          </li>
        </ul>
      </div>
    </div>
  </nav>
  <div class="container" style="margin-top:40px;">
    <table id="example" class="table table-striped table-bordered" style="width:100%">
            <thead>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>Message</th>
                    <th>Date & Time</th>
                    
                </tr>
            </thead>
            <tbody>
                 <?php
                   $cnt=1;
                    foreach($result as $row)
                    {
                    ?>
                    <tr>
                          
                           <td><?php echo $row->name;?></td>
                           <td><?php echo $row->email;?></td>
                           <td><?php echo $row->company;?></td>
                           <td><?php echo $row->message;?></td>
                           <!-- for converting the 24 stamp to 12hour stamp by varun -->
                           <?php $formattedTimestamp = date("Y-m-d h:i:s A", strtotime($row->time)); ?>
                           <td><?php echo $row->time;?></td>
                           
                    </tr>
                    <?php
                    $cnt++;
                   } ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Company</th>
                    <th>Message</th>
                    <th>Date & Time</th>
                    
                </tr>
            </tfoot>
        </table>
    </div>
    <script>$(document).ready(function() {
      $('#example').DataTable();
  } );
  
  </script>
</body>
</html>