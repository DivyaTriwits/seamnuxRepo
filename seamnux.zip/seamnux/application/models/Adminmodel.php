<?php
class Adminmodel extends CI_Model {

    public function authenticate($email, $password) {
        $this->db->where('email', $email);
        $this->db->where('password', $password);
        $query = $this->db->get('admin');
        
        if ($query->num_rows() > 0) {
            return true; // Authentication successful
        } else {
            return false; // Authentication failed
        }
    }

    public function getreachedus(){
    $ret=$this->db->select('*')
                ->order_by('time','DESC')
                  ->get('contacted');
            return $ret->result();
    }
}
?>